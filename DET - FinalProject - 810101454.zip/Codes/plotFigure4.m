% Reproduces the Phase-II normalized-MSE curves in Figure 4.
function [figureHandle, results] = plotFigure4(saveToFile, nTrials, onOffSweepMode)

if nargin < 1
    saveToFile = false;
end
if nargin < 2
    nTrials = 1200;
end
if nargin < 3
    onOffSweepMode = 'singleSweep';
end

SimTools.checkFigureArguments('plotFigure4', ...
    'plotFigure4(true, 2000, ''singleSweep'')', ...
    saveToFile, nTrials, onOffSweepMode, ...
    {'cyclic', 'singleSweep'});

[par, ~, loss, corr] = IrsSystem.buildNumericalExampleScenario();

N = par.N;
K       = par.K;
p  = par.p;
sigma2     = par.sigma2;

tau1 = K;                       % tau_1 = K, eq. (24)
phaseOneDesign = PilotDesign.buildPhaseOneDesign(K, N, ...
                                     tau1);
phaseOneError  = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
                                    tau1);

cascadedCorrelationMatrix = IrsSystem.computeCascadedCorrelationMatrix( ...
    par, loss, corr, 1);
totalChannelPower = real(trace(cascadedCorrelationMatrix));

phaseTwoLengthList = 32:4:64;
numberOfPoints     = length(phaseTwoLengthList);

normalizedMseDftTheory     = zeros(1, numberOfPoints);
normalizedMseDftMonteCarlo = zeros(1, numberOfPoints);
normalizedMseOnOff         = zeros(1, numberOfPoints);
normalizedMseRandomPhase   = zeros(1, numberOfPoints);

for pointIndex = 1:numberOfPoints

    tau2 = phaseTwoLengthList(pointIndex);

    rng(par.seed + 100 * pointIndex);

    phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, ...
        N, tau2, 1);

    typicalUserPilot = phaseTwoDesign.A(1, :).';

    noiseCovariancePhaseTwo = ChannelEstimation.computePhaseTwoNoiseCovariance( ...
        typicalUserPilot, phaseOneError.mse(1), par);

    dftError = ChannelEstimation.computePhaseTwoMse(phaseTwoDesign.Phi, ...
        noiseCovariancePhaseTwo, cascadedCorrelationMatrix, ...
        p);
    normalizedMseDftTheory(pointIndex) = dftError.normalizedMse;

    onOffReflection = PilotDesign.buildComparisonReflectionMatrix(N, ...
        tau2, 'onOff', onOffSweepMode);
    onOffError = ChannelEstimation.computePhaseTwoMse(onOffReflection, ...
        noiseCovariancePhaseTwo, cascadedCorrelationMatrix, ...
        p);
    normalizedMseOnOff(pointIndex) = onOffError.normalizedMse;

    accumulatedSquaredErrorDft = 0;
    accumulatedMseRandomPhase  = 0;

    for trialIndex = 1:nTrials

        ch = IrsSystem.generateChannelRealization(par, loss, corr);

        receivedPhaseOne = IrsSystem.computeReceivedSignal(ch, ...
            phaseOneDesign.A, phaseOneDesign.Phi, ...
            p, sigma2);

        hHat = ChannelEstimation.estimateDirectChannelsMmse( ...
            receivedPhaseOne, phaseOneDesign.A, loss, ...
            p, sigma2);

        receivedPhaseTwo = IrsSystem.computeReceivedSignal(ch, ...
            phaseTwoDesign.A, phaseTwoDesign.Phi, ...
            p, sigma2);

        cascadedEstimates = ChannelEstimation.estimateTypicalCascadedLmmse(receivedPhaseTwo, ...
            hHat, phaseTwoDesign.A, ...
            phaseTwoDesign.Phi, noiseCovariancePhaseTwo, ...
            cascadedCorrelationMatrix, p);

        estimationError = cascadedEstimates ...
                          - ch.g(:, :, 1);

        accumulatedSquaredErrorDft = accumulatedSquaredErrorDft ...
                                     + sum(sum(abs(estimationError).^2));

        randomReflection = PilotDesign.buildComparisonReflectionMatrix( ...
            N, tau2, 'randomPhase');

        randomPhaseError = ChannelEstimation.computePhaseTwoMse(randomReflection, ...
            noiseCovariancePhaseTwo, cascadedCorrelationMatrix, ...
            p);

        accumulatedMseRandomPhase = accumulatedMseRandomPhase ...
                                    + randomPhaseError.normalizedMse;

    end

    normalizedMseDftMonteCarlo(pointIndex) = accumulatedSquaredErrorDft ...
        / (nTrials * totalChannelPower);

    normalizedMseRandomPhase(pointIndex) = accumulatedMseRandomPhase ...
                                           / nTrials;


end

figureHandle = figure('Color', 'w', 'Position', [100, 100, 640, 480]);
hold on;
grid on;
box on;

semilogy(phaseTwoLengthList, normalizedMseDftTheory, ...
    'Color', [1 0 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 'x', 'MarkerSize', 8, ...
    'DisplayName', 'DFT-based Solution: Theoretical Performance');

semilogy(phaseTwoLengthList, normalizedMseDftMonteCarlo, ...
    'Color', [0 0 1], 'LineStyle', '--', 'LineWidth', 1.2, ...
    'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'DFT-based Solution: Monte Carlo Simulation');

semilogy(phaseTwoLengthList, normalizedMseOnOff, ...
    'Color', [0 0.7 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 's', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'On/Off State Control Solution');

semilogy(phaseTwoLengthList, normalizedMseRandomPhase, ...
    'Color', [0.65 0.32 0.17], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', '>', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Random Phase based Solution');

set(gca, 'YScale', 'log');

xlabel('Pilot Sequence Length in Phase II', 'FontSize', 11);
ylabel('Normalized MSE', 'FontSize', 11);

xlim([32, 64]);
ylim([1e-6, 1e-2]);
set(gca, 'XTick', 32:4:64);
set(gca, 'YTick', 10.^(-6:-2));
set(gca, 'FontSize', 10);

legend('Location', 'northeast', 'FontSize', 8);

hold off;

results.phaseTwoLengthList         = phaseTwoLengthList;
results.normalizedMseDftTheory     = normalizedMseDftTheory;
results.normalizedMseDftMonteCarlo = normalizedMseDftMonteCarlo;
results.normalizedMseOnOff         = normalizedMseOnOff;
results.normalizedMseRandomPhase   = normalizedMseRandomPhase;
results.nTrials             = nTrials;
results.tau1             = tau1;
results.onOffSweepMode             = onOffSweepMode;

if saveToFile

    resultsFolder = fullfile(fileparts(mfilename('fullpath')), 'Results');
    if ~exist(resultsFolder, 'dir')
        mkdir(resultsFolder);
    end

    print(figureHandle, fullfile(resultsFolder, 'Figure4.png'), '-dpng', '-r200');
    savefig(figureHandle, fullfile(resultsFolder, 'Figure4.fig'));
    save(fullfile(resultsFolder, 'Figure4.mat'), 'results');

end

end
