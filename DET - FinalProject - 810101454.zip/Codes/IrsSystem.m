classdef IrsSystem
    % Parameters, geometry, fading channels, and the received-signal model.
    methods (Static)
        %% getSystemParameters
        function par = getSystemParameters()

        par.M   = 32;   % M, Section VI ("32 antennas")
        par.N  = 32;   % N, Section VI ("N = 32")
        par.K        = 8;    % K, Section VI ("8 users")

        par.pDbm                  = 33;
        par.noisePowerSpectralDensityDbmPerHz = -169;  % AWGN PSD at the BS
        par.bandwidthHz                       = 1e6;   % 1 MHz

        par.referenceDistanceMeters = 1;     % d0 = 1 m
        par.referencePathLossDb     = -20;   % beta0 = -20 dB
        par.pathLossExponentBsUser  = 4.2;   % alpha1 (BS  <-> user)
        par.pathLossExponentIrsUser = 2.1;   % alpha2 (IRS <-> user)
        par.pathLossExponentBsIrs   = 2.2;   % alpha3 (BS  <-> IRS)

        par.distanceBsToIrsMeters             = 100;
        par.distanceIrsToClusterCenterMeters  = 10;
        par.distanceBsToClusterCenterMeters   = 105;
        par.userClusterRadiusMeters           = 5;

        par.correlationCoefficientBsForDirectChannel = 0.1;  % C_k^B, eq. (1)
        par.correlationCoefficientBsForIrsChannel    = 0.1;  % C^B,   eq. (2)
        par.correlationCoefficientIrsForIrsChannel   = 0.1;  % C^I,   eq. (2)
        par.correlationCoefficientIrsForUserChannel  = 0.1;  % C_k^I, eq. (3)

        par.seed = 2020;

        par.p = SimTools.convertToLinearScale( ...
            par.pDbm, 'dBm');

        sigma2Dbm = par.noisePowerSpectralDensityDbmPerHz ...
                        + 10 * log10(par.bandwidthHz);
        par.sigma2Dbm   = sigma2Dbm;
        par.sigma2 = SimTools.convertToLinearScale(sigma2Dbm, 'dBm'); % sigma^2

        end

        %% generateUserPositions
        function pos = generateUserPositions(par)

        distanceBsToIrs            = par.distanceBsToIrsMeters;
        distanceBsToClusterCenter  = par.distanceBsToClusterCenterMeters;
        distanceIrsToClusterCenter = par.distanceIrsToClusterCenterMeters;

        pos.basestationPosition = [0, 0];
        pos.irsPosition         = [distanceBsToIrs, 0];

        clusterCenterX = (distanceBsToClusterCenter^2 ...
                          - distanceIrsToClusterCenter^2 ...
                          + distanceBsToIrs^2) / (2 * distanceBsToIrs);

        clusterCenterYSquared = distanceBsToClusterCenter^2 - clusterCenterX^2;

        if clusterCenterYSquared < 0
            error('generateUserPositions:inconsistentGeometry', ...
                  ['The three distances are inconsistent: no point in the ' ...
                   'plane is simultaneously at %.1f m from the BS and %.1f m ' ...
                   'from the IRS when the BS-IRS distance is %.1f m.'], ...
                  distanceBsToClusterCenter, distanceIrsToClusterCenter, ...
                  distanceBsToIrs);
        end

        clusterCenterY = sqrt(clusterCenterYSquared);
        pos.userClusterCenter = [clusterCenterX, clusterCenterY];

        K  = par.K;
        clusterRadius  = par.userClusterRadiusMeters;
        pos.userPositions = zeros(K, 2);

        for k = 1:K
            randomRadius = clusterRadius * sqrt(rand);   % uniform over the AREA
            randomAngle  = 2 * pi * rand;                % uniform over [0, 2*pi)

            pos.userPositions(k, 1) = ...
                clusterCenterX + randomRadius * cos(randomAngle);
            pos.userPositions(k, 2) = ...
                clusterCenterY + randomRadius * sin(randomAngle);
        end

        end

        %% computePathLosses
        function loss = computePathLosses(par, pos)

        referencePathLossLinear = SimTools.convertToLinearScale( ...
            par.referencePathLossDb, 'dB');
        referenceDistance       = par.referenceDistanceMeters;
        K           = par.K;

        loss.distanceBsToUser  = zeros(K, 1);
        loss.distanceIrsToUser = zeros(K, 1);
        loss.betaBU        = zeros(K, 1);
        loss.betaIU       = zeros(K, 1);

        for k = 1:K

            userPosition = pos.userPositions(k, :);

            loss.distanceBsToUser(k) = ...
                norm(userPosition - pos.basestationPosition);
            loss.distanceIrsToUser(k) = ...
                norm(userPosition - pos.irsPosition);

            loss.betaBU(k) = referencePathLossLinear * ...
                (loss.distanceBsToUser(k) / referenceDistance) ...
                ^(-par.pathLossExponentBsUser);

            loss.betaIU(k) = referencePathLossLinear * ...
                (loss.distanceIrsToUser(k) / referenceDistance) ...
                ^(-par.pathLossExponentIrsUser);

        end

        loss.distanceBsToIrs = ...
            norm(pos.irsPosition - pos.basestationPosition);

        loss.betaBI = referencePathLossLinear * ...
            (loss.distanceBsToIrs / referenceDistance) ...
            ^(-par.pathLossExponentBsIrs);

        end

        %% buildCorrelationMatrices
        function corr = buildCorrelationMatrices(par)

        M  = par.M;
        N = par.N;
        K       = par.K;

        corr.bsForDirectChannel     = zeros(M,  M,  K);
        corr.bsForDirectChannelSqrt = zeros(M,  M,  K);
        corr.irsForUserChannel      = zeros(N, N, K);
        corr.irsForUserChannelSqrt  = zeros(N, N, K);

        for k = 1:K

            matrixCkB = SimTools.exponentialCorrelationMatrix( ...
                M, ...
                par.correlationCoefficientBsForDirectChannel);
            corr.bsForDirectChannel(:, :, k)     = matrixCkB;
            corr.bsForDirectChannelSqrt(:, :, k) = SimTools.hermitianSquareRoot(matrixCkB);

            matrixCkI = SimTools.exponentialCorrelationMatrix( ...
                N, ...
                par.correlationCoefficientIrsForUserChannel);
            corr.irsForUserChannel(:, :, k)     = matrixCkI;
            corr.irsForUserChannelSqrt(:, :, k) = SimTools.hermitianSquareRoot(matrixCkI);

        end

        corr.bsForIrsChannel = SimTools.exponentialCorrelationMatrix( ...
            M, ...
            par.correlationCoefficientBsForIrsChannel);
        corr.bsForIrsChannelSqrt = SimTools.hermitianSquareRoot(corr.bsForIrsChannel);

        corr.irsForIrsChannel = SimTools.exponentialCorrelationMatrix( ...
            N, ...
            par.correlationCoefficientIrsForIrsChannel);
        corr.irsForIrsChannelSqrt = SimTools.hermitianSquareRoot(corr.irsForIrsChannel);

        end

        %% generateChannelRealization
        function ch = generateChannelRealization(par, loss, corr)

        M  = par.M;
        N = par.N;
        K       = par.K;

        ch.h = zeros(M, K);

        for k = 1:K

            iidDirectChannel = SimTools.generateIidComplexGaussian( ...
                M, 1, loss.betaBU(k));

            ch.h(:, k) = ...
                corr.bsForDirectChannelSqrt(:, :, k) * iidDirectChannel;

        end

        iidIrsToBsChannel = SimTools.generateIidComplexGaussian( ...
            M, N, loss.betaBI);

        ch.R = corr.bsForIrsChannelSqrt ...
                                  * iidIrsToBsChannel ...
                                  * corr.irsForIrsChannelSqrt;

        ch.t = zeros(N, K);

        for k = 1:K

            iidUserToIrsChannel = SimTools.generateIidComplexGaussian( ...
                N, 1, loss.betaIU(k));

            ch.t(:, k) = ...
                corr.irsForUserChannelSqrt(:, :, k) * iidUserToIrsChannel;

        end

        ch.g = IrsSystem.computeCascadedChannels( ...
            ch.R, ch.t);

        ch.lambda = IrsSystem.computeRatioCoefficients( ...
            ch.t, 1);

        end

        function g = computeCascadedChannels(R, t)

        M  = size(R, 1);
        N = size(R, 2);
        K       = size(t, 2);

        g = zeros(M, N, K);

        for k = 1:K
            for n = 1:N

                scalarUserToElement = t(n, k);
                vectorElementToBs   = R(:, n);

                g(:, n, k) = ...
                    scalarUserToElement * vectorElementToBs;

            end
        end

        end

        function lambda = computeRatioCoefficients(t, typicalUserIndex)

        if nargin < 2
            typicalUserIndex = 1;
        end

        N = size(t, 1);
        K       = size(t, 2);

        lambda = zeros(N, K);

        for k = 1:K
            for n = 1:N

                numeratorChannel   = t(n, k);
                denominatorChannel = t(n, typicalUserIndex);

                lambda(n, k) = ...
                    numeratorChannel / denominatorChannel;

            end
        end

        end

        %% computeReceivedSignal
        function receivedSignal = computeReceivedSignal(ch, A, Phi, p, sigma2)

        M  = size(ch.h, 1);
        K       = size(A, 1);
        N = size(Phi, 1);
        pilotLength         = size(A, 2);

        if size(Phi, 2) ~= pilotLength
            error('computeReceivedSignal:lengthMismatch', ...
                  ['The pilot matrix has %d time slots but the reflection ' ...
                   'matrix has %d.'], pilotLength, size(Phi, 2));
        end

        if size(ch.g, 2) ~= N
            error('computeReceivedSignal:elementMismatch', ...
                  ['The channel realization has %d IRS elements but the ' ...
                   'reflection matrix has %d rows.'], ...
                  size(ch.g, 2), N);
        end

        receivedSignal = zeros(M, pilotLength);

        squareRootOfTransmitPower = sqrt(p);

        for i = 1:pilotLength

            reflectionVectorAtThisTime = Phi(:, i);

            superposedSignal = zeros(M, 1);

            for k = 1:K

                cascadedMatrixOfThisUser = ch.g(:, :, k);

                reflectedContribution = cascadedMatrixOfThisUser * reflectionVectorAtThisTime;

                effectiveChannel = ch.h(:, k) ...
                                   + reflectedContribution;

                superposedSignal = superposedSignal ...
                    + effectiveChannel * squareRootOfTransmitPower ...
                      * A(k, i);

            end

            if sigma2 > 0
                noiseVector = SimTools.generateIidComplexGaussian(M, 1, ...
                                                         sigma2);
            else
                noiseVector = zeros(M, 1);
            end

            receivedSignal(:, i) = superposedSignal + noiseVector;

        end

        end

        %% computeCascadedCorrelationMatrix
        function cascadedCorrelationMatrix = computeCascadedCorrelationMatrix(par, loss, corr, k)

        if nargin < 4
            k = 1;
        end

        M = par.M;

        transposedIrsUserCorrelation = corr.irsForUserChannel(:, :, k).';
        hadamardProduct = transposedIrsUserCorrelation .* corr.irsForIrsChannel;

        cascadedCorrelationMatrix = M ...
                                    * loss.betaBI ...
                                    * loss.betaIU(k) ...
                                    * hadamardProduct;

        cascadedCorrelationMatrix = ...
            (cascadedCorrelationMatrix + cascadedCorrelationMatrix') / 2;

        end

        %% buildNumericalExampleScenario
        function [par, pos, loss, corr] = buildNumericalExampleScenario(typicalUserDistanceToIrs)

        if nargin < 1
            typicalUserDistanceToIrs = 10;
        end

        par = IrsSystem.getSystemParameters();

        par.M   = 32;
        par.N  = 32;
        par.K        = 8;

        rng(par.seed);

        pos = IrsSystem.generateUserPositions(par);

        bearingFromIrsToCentre = pos.userClusterCenter - pos.irsPosition;
        bearingFromIrsToCentre = bearingFromIrsToCentre / norm(bearingFromIrsToCentre);

        pos.userPositions(1, :) = pos.irsPosition ...
            + typicalUserDistanceToIrs * bearingFromIrsToCentre;

        pos.typicalUserDistanceToIrs = typicalUserDistanceToIrs;

        loss    = IrsSystem.computePathLosses(par, pos);
        corr = IrsSystem.buildCorrelationMatrices(par);

        end

    end
end
