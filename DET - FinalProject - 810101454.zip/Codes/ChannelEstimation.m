classdef ChannelEstimation
    % Noiseless, MMSE, and LMMSE estimators for the three phases.
    methods (Static)
        %% computeBenchmarkOverallMse
        function benchmarkError = computeBenchmarkOverallMse(tau, loss, corr, par)

        K       = par.K;
        N = par.N;
        M  = par.M;
        p  = par.p;

        tau1 = K;
        tau2 = N;
        tau3 = tau - tau1 - tau2;

        phaseOneError = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
                                           tau1);

        benchmarkError.directMse = sum(phaseOneError.mse);

        phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, N, ...
                                             tau2, 1);

        noiseCovarianceTypical = ChannelEstimation.computePhaseTwoNoiseCovariance( ...
            phaseTwoDesign.A(1, :).', phaseOneError.mse(1), par);

        cascadedCorrelationTypical = IrsSystem.computeCascadedCorrelationMatrix( ...
            par, loss, corr, 1);

        typicalError = ChannelEstimation.computePhaseTwoMse(phaseTwoDesign.Phi, ...
            noiseCovarianceTypical, cascadedCorrelationTypical, p);

        benchmarkError.typicalUserMse = typicalError.mse;

        benchmarkDesign = PilotDesign.buildBenchmarkPhaseThreeDesign(K, ...
            N, tau3);

        otherUsersError = ChannelEstimation.computeBenchmarkPhaseThreeMse(benchmarkDesign, ...
            loss, corr, par, tau1);

        benchmarkError.otherUsersMse  = otherUsersError.totalMse;
        benchmarkError.symbolsPerUser = benchmarkDesign.symbolsPerUser;

        directPower    = M * sum(loss.betaBU);
        reflectedPower = 0;
        for k = 1:K
            reflectedPower = reflectedPower + real(trace( ...
                IrsSystem.computeCascadedCorrelationMatrix(par, loss, ...
                                                 corr, k)));
        end

        benchmarkError.totalMse   = benchmarkError.directMse ...
                                    + benchmarkError.typicalUserMse ...
                                    + benchmarkError.otherUsersMse;
        benchmarkError.totalPower = directPower + reflectedPower;

        benchmarkError.normalizedMse = benchmarkError.totalMse ...
                                       / benchmarkError.totalPower;

        end

        %% computeBenchmarkPhaseThreeMse
        function benchmarkError = computeBenchmarkPhaseThreeMse(benchmarkDesign, loss, corr, par, tau1)

        K       = par.K;
        N = par.N;
        p  = par.p;

        phaseOneError = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
                                           tau1);

        symbolsPerUser = benchmarkDesign.symbolsPerUser;

        benchmarkError.msePerUser = zeros(K - 1, 1);
        totalChannelPower         = 0;

        for k = 2:K

            userCounter = k - 1;

            Phi = benchmarkDesign.Phi{userCounter};

            userPilot = ones(symbolsPerUser(userCounter), 1);

            noiseCovariance = ChannelEstimation.computePhaseTwoNoiseCovariance(userPilot, ...
                phaseOneError.mse(k), par);

            cascadedCorrelationMatrix = IrsSystem.computeCascadedCorrelationMatrix( ...
                par, loss, corr, k);

            userError = ChannelEstimation.computePhaseTwoMse(Phi, noiseCovariance, ...
                cascadedCorrelationMatrix, p);

            benchmarkError.msePerUser(userCounter) = userError.mse;

            totalChannelPower = totalChannelPower ...
                                + real(trace(cascadedCorrelationMatrix));

        end

        benchmarkError.totalMse      = sum(benchmarkError.msePerUser);
        benchmarkError.normalizedMse = benchmarkError.totalMse / totalChannelPower;

        benchmarkError.rankFloor = 1 - mean(symbolsPerUser) / N;

        end

        %% computeEffectiveSignalPhaseThree
        function effectiveSignal = computeEffectiveSignalPhaseThree(receivedSignalPhaseThree, hHat, pilotMatrixPhaseThree, p)

        effectiveSignal = receivedSignalPhaseThree ...
            - sqrt(p) * hHat * pilotMatrixPhaseThree;

        end

        %% computePhaseOneMse
        function phaseOneError = computePhaseOneMse(loss, corr, par, tau1)

        M = par.M;
        K      = par.K;
        p = par.p;
        sigma2    = par.sigma2;

        phaseOneError.mse             = zeros(K, 1);
        phaseOneError.normalizedMse   = zeros(K, 1);
        phaseOneError.errorCovariance = zeros(M, ...
                                              M, K);

        for k = 1:K

            pathLossOfThisUser = loss.betaBU(k);

            commonDenominator = pathLossOfThisUser * p ...
                                * tau1 + sigma2;

            phaseOneError.mse(k) = M ...
                * pathLossOfThisUser * sigma2 / commonDenominator;

            phaseOneError.normalizedMse(k) = ...
                sigma2 / commonDenominator;

            correlationOfThisUser = corr.bsForDirectChannel(:, :, k);

            channelTerm = sigma2^2 * pathLossOfThisUser ...
                          * correlationOfThisUser;

            noiseTerm = pathLossOfThisUser^2 * p ...
                        * sigma2 * tau1 ...
                        * eye(M);

            phaseOneError.errorCovariance(:, :, k) = ...
                (channelTerm + noiseTerm) / commonDenominator^2;

        end

        phaseOneError.totalMse = sum(phaseOneError.mse);

        end

        %% computePhaseThreeMse
        function phaseThreeError = computePhaseThreeMse(G1, phaseThreeDesign, loss, corr, par, tau1, priorMode)

        if nargin < 7
            priorMode = 'nonInformative';
        end

        p = par.p;

        phaseThreeError.msePerSlot = zeros(phaseThreeDesign.phaseLength, 1);

        for localSlotIndex = 1:phaseThreeDesign.phaseLength

            activeUserIndex = phaseThreeDesign.activeUser(localSlotIndex);
            activeElements  = phaseThreeDesign.activeElements{localSlotIndex};

            reducedChannelMatrix = G1(:, activeElements);

            statistics = ChannelEstimation.computePhaseThreeStatistics(activeUserIndex, ...
                activeElements, loss, corr, par, ...
                tau1, priorMode);

            noiseCovariancePhaseThree = statistics.noiseCovariance;

            priorCovariance = statistics.priorCovariance;

            whitenedChannel = noiseCovariancePhaseThree \ reducedChannelMatrix;

            posteriorPrecisionMatrix = p ...
                * reducedChannelMatrix' * whitenedChannel;

            if ~isempty(priorCovariance)
                posteriorPrecisionMatrix = posteriorPrecisionMatrix ...
                                           + inv(priorCovariance);
            end

            posteriorPrecisionMatrix = ...
                (posteriorPrecisionMatrix + posteriorPrecisionMatrix') / 2;

            phaseThreeError.msePerSlot(localSlotIndex) = ...
                real(trace(inv(posteriorPrecisionMatrix)));

        end

        phaseThreeError.totalMse = sum(phaseThreeError.msePerSlot);

        end

        %% computePhaseThreeStatistics
        function statistics = computePhaseThreeStatistics(activeUserIndex, activeElements, loss, corr, par, tau1, priorMode, usePrintedEquation)

        if nargin < 7 || isempty(priorMode)
            priorMode = 'nonInformative';
        end
        if nargin < 8 || isempty(usePrintedEquation)
            usePrintedEquation = false;
        end

        M = par.M;
        p = par.p;
        sigma2    = par.sigma2;

        pathLossOfActiveUser = loss.betaBU(activeUserIndex);
        correlationOfActiveUser = corr.bsForDirectChannel(:, :, activeUserIndex);

        commonDenominator = pathLossOfActiveUser * p ...
                            * tau1 + sigma2;

        if usePrintedEquation
            denominatorPower = commonDenominator;
        else
            denominatorPower = commonDenominator^2;
        end

        correlatedTerm = pathLossOfActiveUser * p ...
            * sigma2^2 / denominatorPower * correlationOfActiveUser;

        whiteResidualTerm = (pathLossOfActiveUser * p)^2 ...
            * tau1 * sigma2 / denominatorPower ...
            * eye(M);

        receiverNoiseTerm = sigma2 * eye(M);

        noiseCovariancePhaseThree = correlatedTerm + whiteResidualTerm ...
                                    + receiverNoiseTerm;

        noiseCovariancePhaseThree = ...
            (noiseCovariancePhaseThree + noiseCovariancePhaseThree') / 2;
        statistics.noiseCovariance = noiseCovariancePhaseThree;

        if isempty(activeElements)
            statistics.priorCovariance = [];
            return;
        end

        numberOfActiveElements = length(activeElements);

        switch priorMode

            case 'pathLossRatio'
                pathLossRatio = loss.betaIU(activeUserIndex) ...
                                / loss.betaIU(1);

                priorCovariance = pathLossRatio * eye(numberOfActiveElements);

            case 'nonInformative'
                priorCovariance = [];

            otherwise
                error('computePhaseThreeStatistics:unknownPriorMode', ...
                      'priorMode must be ''pathLossRatio'' or ''nonInformative''.');

        end
        statistics.priorCovariance = priorCovariance;

        end

        %% computePhaseTwoMse
        function phaseTwoError = computePhaseTwoMse(reflectionMatrixPhaseTwo, noiseCovariancePhaseTwo, cascadedCorrelationMatrix, p)

        whitenedReflection = noiseCovariancePhaseTwo \ reflectionMatrixPhaseTwo';

        posteriorPrecisionMatrix = p ...
            * reflectionMatrixPhaseTwo * whitenedReflection ...
            + inv(cascadedCorrelationMatrix);

        posteriorPrecisionMatrix = ...
            (posteriorPrecisionMatrix + posteriorPrecisionMatrix') / 2;

        phaseTwoError.posteriorCovariance = inv(posteriorPrecisionMatrix);

        phaseTwoError.mse = real(trace(phaseTwoError.posteriorCovariance));

        phaseTwoError.normalizedMse = phaseTwoError.mse ...
                                      / real(trace(cascadedCorrelationMatrix));

        end

        %% computePhaseTwoNoiseCovariance
        function noiseCovariancePhaseTwo = computePhaseTwoNoiseCovariance(typicalUserPilot, phaseOneMseTypicalUser, par)

        M = par.M;
        sigma2    = par.sigma2;
        p = par.p;

        tau2 = length(typicalUserPilot);

        typicalUserPilot = typicalUserPilot(:);

        propagatedErrorTerm = p * phaseOneMseTypicalUser ...
            * conj(typicalUserPilot) * typicalUserPilot.';

        receiverNoiseTerm = M * sigma2 ...
                            * eye(tau2);

        noiseCovariancePhaseTwo = propagatedErrorTerm + receiverNoiseTerm;

        noiseCovariancePhaseTwo = ...
            (noiseCovariancePhaseTwo + noiseCovariancePhaseTwo') / 2;

        end

        %% estimateDirectChannelsMmse
        function hHat = estimateDirectChannelsMmse(receivedSignalPhaseOne, pilotMatrixPhaseOne, loss, p, sigma2, correlationMatrices)

        if nargin < 6
            correlationMatrices = [];
        end

        M = size(receivedSignalPhaseOne, 1);
        K      = size(pilotMatrixPhaseOne, 1);
        tau1     = size(pilotMatrixPhaseOne, 2);

        hHat = zeros(M, K);

        useCorrelationAwareEstimator = ~isempty(correlationMatrices);

        for k = 1:K

            pathLossOfThisUser = loss.betaBU(k);

            matchedFilterOutput = receivedSignalPhaseOne ...
                                  * pilotMatrixPhaseOne(k, :)';

            if ~useCorrelationAwareEstimator

                wienerScalingFactor = pathLossOfThisUser * sqrt(p) ...
                    / (pathLossOfThisUser * p * tau1 ...
                       + sigma2);

                hHat(:, k) = ...
                    wienerScalingFactor * matchedFilterOutput;

            else

                correlationOfThisUser = correlationMatrices(:, :, k);

                systemMatrix = pathLossOfThisUser * p ...
                               * tau1 * correlationOfThisUser ...
                               + sigma2 * eye(M);

                hHat(:, k) = ...
                    pathLossOfThisUser * sqrt(p) ...
                    * correlationOfThisUser * (systemMatrix \ matchedFilterOutput);

            end

        end

        end

        %% estimateDirectChannelsNoiseless
        function hHat = estimateDirectChannelsNoiseless(receivedSignalPhaseOne, pilotMatrixPhaseOne, p)

        tau1 = size(pilotMatrixPhaseOne, 2);

        hHat = receivedSignalPhaseOne * pilotMatrixPhaseOne' ...
                                 / (tau1 * sqrt(p));

        end

        %% estimateRatioCoefficientsLmmse
        function lambdaHat = estimateRatioCoefficientsLmmse(effectiveSignalPhaseThree, G1Hat, phaseThreeDesign, loss, corr, par, tau1, priorMode)

        if nargin < 8
            priorMode = 'nonInformative';
        end

        N = size(G1Hat, 2);
        K       = size(phaseThreeDesign.A, 1);
        p  = par.p;

        lambdaHat = zeros(N, K);

        lambdaHat(:, 1) = ones(N, 1);

        for localSlotIndex = 1:phaseThreeDesign.phaseLength

            activeUserIndex = phaseThreeDesign.activeUser(localSlotIndex);
            activeElements  = phaseThreeDesign.activeElements{localSlotIndex};

            reducedChannelMatrix = G1Hat(:, activeElements);

            statistics = ChannelEstimation.computePhaseThreeStatistics(activeUserIndex, ...
                activeElements, loss, corr, par, ...
                tau1, priorMode);

            noiseCovariancePhaseThree = statistics.noiseCovariance;

            priorCovariance = statistics.priorCovariance;

            whitenedChannel = noiseCovariancePhaseThree \ reducedChannelMatrix;

            posteriorPrecisionMatrix = p ...
                * reducedChannelMatrix' * whitenedChannel;

            if ~isempty(priorCovariance)
                posteriorPrecisionMatrix = posteriorPrecisionMatrix ...
                                           + inv(priorCovariance);
            end

            posteriorPrecisionMatrix = ...
                (posteriorPrecisionMatrix + posteriorPrecisionMatrix') / 2;

            observedVector = effectiveSignalPhaseThree(:, localSlotIndex);

            solvedRatioValues = sqrt(p) ...
                * (posteriorPrecisionMatrix \ (whitenedChannel' * observedVector));

            for positionIndex = 1:length(activeElements)
                n = activeElements(positionIndex);
                lambdaHat(n, activeUserIndex) = ...
                    solvedRatioValues(positionIndex);
            end

        end

        end

        %% estimateRatioCoefficientsTheoremOne
        function lambdaHat = estimateRatioCoefficientsTheoremOne(effectiveSignalPhaseThree, G1Hat, p)

        M  = size(G1Hat, 1);
        N = size(G1Hat, 2);
        tau3    = size(effectiveSignalPhaseThree, 2);

        if M < N
            error('estimateRatioCoefficientsTheoremOne:caseNotApplicable', ...
                  ['Equation (41) needs M >= N so that [g_{1,1},...,g_{1,N}] has ' ...
                   'full column rank, but M = %d and N = %d.'], ...
                  M, N);
        end

        K = tau3 + 1;

        lambdaHat = zeros(N, K);

        lambdaHat(:, 1) = ones(N, 1);

        for k = 2:K

            localTimeIndex = k - 1;

            observedVector = effectiveSignalPhaseThree(:, localTimeIndex) ...
                             / sqrt(p);

            lambdaHat(:, k) = ...
                G1Hat \ observedVector;

        end

        end

        %% estimateRatioCoefficientsTheoremTwo
        function lambdaHat = estimateRatioCoefficientsTheoremTwo(effectiveSignalPhaseThree, G1Hat, phaseThreeDesign, p)

        N = size(G1Hat, 2);
        sets                = phaseThreeDesign.sets;
        K       = size(phaseThreeDesign.A, 1);

        lambdaHat = zeros(N, K);

        lambdaHat(:, 1) = ones(N, 1);

        squareRootOfTransmitPower = sqrt(p);

        for slotIndex = 1:sets.firstRegimeLength

            activeUserIndex = sets.firstRegimeUser(slotIndex);
            activeElements  = sets.omegaSet{slotIndex};

            reducedChannelMatrix = G1Hat(:, activeElements);

            observedVector = effectiveSignalPhaseThree(:, slotIndex) ...
                             / squareRootOfTransmitPower;

            solvedRatioValues = reducedChannelMatrix \ observedVector;

            for positionIndex = 1:length(activeElements)
                n = activeElements(positionIndex);
                lambdaHat(n, activeUserIndex) = ...
                    solvedRatioValues(positionIndex);
            end

        end

        for slotIndex = (sets.firstRegimeLength + 1):sets.tau3

            activeUsers      = sets.kSet{slotIndex};
            activeElements   = sets.nSet{slotIndex};
            userOfEachUnknown = sets.secondRegimeUser{slotIndex};

            residualSignal = effectiveSignalPhaseThree(:, slotIndex);

            for userPosition = 1:length(activeUsers)

                activeUserIndex = activeUsers(userPosition);

                alreadyKnownElements = intersect(activeElements, ...
                                                 sets.lambdaSetOne{activeUserIndex});

                for positionIndex = 1:length(alreadyKnownElements)

                    n = alreadyKnownElements(positionIndex);

                    knownRatioValue = ...
                        lambdaHat(n, activeUserIndex);

                    residualSignal = residualSignal ...
                        - squareRootOfTransmitPower * knownRatioValue ...
                          * G1Hat(:, n);

                end

            end

            reducedChannelMatrix = G1Hat(:, activeElements);

            observedVector = residualSignal / squareRootOfTransmitPower;

            solvedRatioValues = reducedChannelMatrix \ observedVector;

            for positionIndex = 1:length(activeElements)
                n    = activeElements(positionIndex);
                activeUserIndex = userOfEachUnknown(positionIndex);
                lambdaHat(n, activeUserIndex) = ...
                    solvedRatioValues(positionIndex);
            end

        end

        end

        %% estimateRatiosOverSlots
        function estimatedRatios = estimateRatiosOverSlots(observedSignals, G1Hat, reflectionPhaseList, noiseCovariance, p, combineMode)

        N = size(G1Hat, 2);
        numberOfSlots       = size(observedSignals, 2);

        switch combineMode

            case 'average'
                accumulatedEstimate = zeros(N, 1);

                for slotIndex = 1:numberOfSlots

                    rotatedChannelMatrix = G1Hat ...
                                           .* reflectionPhaseList{slotIndex};

                    whitenedChannel = noiseCovariance \ rotatedChannelMatrix;

                    posteriorPrecision = p ...
                        * (rotatedChannelMatrix' * whitenedChannel);
                    posteriorPrecision = ...
                        (posteriorPrecision + posteriorPrecision') / 2;

                    accumulatedEstimate = accumulatedEstimate ...
                        + sqrt(p) ...
                          * (posteriorPrecision ...
                             \ (whitenedChannel' * observedSignals(:, slotIndex)));

                end

                estimatedRatios = accumulatedEstimate / numberOfSlots;

            case 'joint'
                posteriorPrecision = zeros(N, N);
                correlationVector  = zeros(N, 1);

                for slotIndex = 1:numberOfSlots

                    rotatedChannelMatrix = G1Hat ...
                                           .* reflectionPhaseList{slotIndex};

                    whitenedChannel = noiseCovariance \ rotatedChannelMatrix;

                    posteriorPrecision = posteriorPrecision + p ...
                        * (rotatedChannelMatrix' * whitenedChannel);
                    correlationVector = correlationVector ...
                        + whitenedChannel' * observedSignals(:, slotIndex);

                end

                posteriorPrecision = (posteriorPrecision + posteriorPrecision') / 2;

                estimatedRatios = sqrt(p) ...
                                  * (posteriorPrecision \ correlationVector);

            otherwise
                error('estimateRatiosOverSlots:unknownCombineMode', ...
                      'combineMode must be ''average'' or ''joint''.');

        end

        end

        %% estimateTypicalCascadedLmmse
        function [G1Hat, effectiveReceivedSignal] = estimateTypicalCascadedLmmse(receivedSignalPhaseTwo, hHat, pilotMatrixPhaseTwo, reflectionMatrixPhaseTwo, noiseCovariancePhaseTwo, cascadedCorrelationMatrix, p)

        effectiveReceivedSignal = receivedSignalPhaseTwo ...
            - sqrt(p) * hHat * pilotMatrixPhaseTwo;

        whitenedReflection = noiseCovariancePhaseTwo \ reflectionMatrixPhaseTwo';

        posteriorPrecisionMatrix = p ...
            * reflectionMatrixPhaseTwo * whitenedReflection ...
            + inv(cascadedCorrelationMatrix);

        posteriorPrecisionMatrix = ...
            (posteriorPrecisionMatrix + posteriorPrecisionMatrix') / 2;

        G1Hat = sqrt(p) ...
            * effectiveReceivedSignal * whitenedReflection ...
            / posteriorPrecisionMatrix;

        end

        %% estimateTypicalCascadedNoiseless
        function [G1Hat, effectiveReceivedSignal] = estimateTypicalCascadedNoiseless(receivedSignalPhaseTwo, hHat, pilotMatrixPhaseTwo, reflectionMatrixPhaseTwo, p)

        tau2 = size(reflectionMatrixPhaseTwo, 2);

        effectiveReceivedSignal = receivedSignalPhaseTwo ...
            - sqrt(p) * hHat * pilotMatrixPhaseTwo;

        nonZeroPilotRows = find(any(pilotMatrixPhaseTwo ~= 0, 2));
        if numel(nonZeroPilotRows) == 1
            typicalPilotRow = pilotMatrixPhaseTwo(nonZeroPilotRows, :);
            if max(abs(typicalPilotRow - 1)) > 1e-12
                warning('estimateTypicalCascadedNoiseless:pilotNotAllOnes', ...
                        ['Equation (34) assumes a_1^II = [1,...,1]^T (eq. 31). ' ...
                         'The supplied pilot is different, so the estimate will ' ...
                         'be biased by the missing diag(a_1^II)^(-1) factor.']);
            end
        end

        G1Hat = effectiveReceivedSignal * reflectionMatrixPhaseTwo' ...
                                   / (tau2 * sqrt(p));

        end

        %% reconstructCascadedChannels
        function gHat = reconstructCascadedChannels(G1Hat, lambdaHat)

        M  = size(G1Hat, 1);
        N = size(G1Hat, 2);
        K       = size(lambdaHat, 2);

        gHat = zeros(M, N, K);

        for k = 1:K
            for n = 1:N

                scalarRatio          = lambdaHat(n, k);
                typicalChannelVector = G1Hat(:, n);

                gHat(:, n, k) = ...
                    scalarRatio * typicalChannelVector;

            end
        end

        end

        %% runThreePhaseProtocol
        function estimates = runThreePhaseProtocol(ch, par, loss, corr, allocation)

        K       = par.K;
        N = par.N;
        M  = par.M;
        p  = par.p;
        sigma2     = par.sigma2;

        if nargin < 5 || isempty(allocation)
            allocation.tau1   = K;
            allocation.tau2   = N;
            allocation.tau3 = (K - 1) ...
                * ceil(N / M);
        end

        tau1   = allocation.tau1;
        tau2   = allocation.tau2;
        tau3 = allocation.tau3;

        phaseOneDesign = PilotDesign.buildPhaseOneDesign(K, N, ...
                                             tau1);

        receivedPhaseOne = IrsSystem.computeReceivedSignal(ch, ...
            phaseOneDesign.A, phaseOneDesign.Phi, ...
            p, sigma2);

        estimates.h = ChannelEstimation.estimateDirectChannelsMmse(receivedPhaseOne, ...
            phaseOneDesign.A, loss, p, ...
            sigma2);

        phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, N, ...
                                             tau2, 1);

        phaseOneError = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
                                           tau1);

        noiseCovariancePhaseTwo = ChannelEstimation.computePhaseTwoNoiseCovariance( ...
            phaseTwoDesign.A(1, :).', phaseOneError.mse(1), par);

        cascadedCorrelationMatrix = IrsSystem.computeCascadedCorrelationMatrix( ...
            par, loss, corr, 1);

        receivedPhaseTwo = IrsSystem.computeReceivedSignal(ch, ...
            phaseTwoDesign.A, phaseTwoDesign.Phi, ...
            p, sigma2);

        estimates.typicalCascaded = ChannelEstimation.estimateTypicalCascadedLmmse(receivedPhaseTwo, ...
            estimates.h, phaseTwoDesign.A, ...
            phaseTwoDesign.Phi, noiseCovariancePhaseTwo, ...
            cascadedCorrelationMatrix, p);

        phaseThreeDesign = PilotDesign.buildPhaseThreeDesignOrthogonal(K, ...
            N, M);

        receivedPhaseThree = IrsSystem.computeReceivedSignal(ch, ...
            phaseThreeDesign.A, phaseThreeDesign.Phi, ...
            p, sigma2);

        effectiveSignalPhaseThree = ChannelEstimation.computeEffectiveSignalPhaseThree( ...
            receivedPhaseThree, estimates.h, ...
            phaseThreeDesign.A, p);

        estimates.lambda = ChannelEstimation.estimateRatioCoefficientsLmmse( ...
            effectiveSignalPhaseThree, estimates.typicalCascaded, ...
            phaseThreeDesign, loss, corr, par, tau1);

        estimates.g = ChannelEstimation.reconstructCascadedChannels( ...
            estimates.typicalCascaded, estimates.lambda);

        estimates.allocation        = allocation;
        estimates.tau  = tau1 + tau2 ...
                                      + tau3;

        end

        %% runNoiselessThreePhase
        function results = runNoiselessThreePhase(par, ch)

        M  = par.M;
        N = par.N;
        K       = par.K;
        p  = par.p;

        noiselessNoisePower = 0;

        phaseOneDesign = PilotDesign.buildPhaseOneDesign(K, N, ...
                                             K);

        receivedPhaseOne = IrsSystem.computeReceivedSignal(ch, ...
            phaseOneDesign.A, phaseOneDesign.Phi, ...
            p, noiselessNoisePower);

        results.hHat = ChannelEstimation.estimateDirectChannelsNoiseless( ...
            receivedPhaseOne, phaseOneDesign.A, p);

        phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, N, ...
                                             N, 1);

        receivedPhaseTwo = IrsSystem.computeReceivedSignal(ch, ...
            phaseTwoDesign.A, phaseTwoDesign.Phi, ...
            p, noiselessNoisePower);

        results.G1Hat = ChannelEstimation.estimateTypicalCascadedNoiseless( ...
            receivedPhaseTwo, results.hHat, ...
            phaseTwoDesign.A, phaseTwoDesign.Phi, ...
            p);

        phaseThreeDesign = PilotDesign.buildPhaseThreeDesignNoiseless(K, ...
            N, M);

        receivedPhaseThree = IrsSystem.computeReceivedSignal(ch, ...
            phaseThreeDesign.A, phaseThreeDesign.Phi, ...
            p, noiselessNoisePower);

        effectiveSignalPhaseThree = ChannelEstimation.computeEffectiveSignalPhaseThree( ...
            receivedPhaseThree, results.hHat, ...
            phaseThreeDesign.A, p);

        if phaseThreeDesign.theorem == 1
            results.lambdaHat = ...
                ChannelEstimation.estimateRatioCoefficientsTheoremOne(effectiveSignalPhaseThree, ...
                    results.G1Hat, p);
        else
            results.lambdaHat = ...
                ChannelEstimation.estimateRatioCoefficientsTheoremTwo(effectiveSignalPhaseThree, ...
                    results.G1Hat, phaseThreeDesign, ...
                    p);
        end

        results.gHat = ChannelEstimation.reconstructCascadedChannels( ...
            results.G1Hat, results.lambdaHat);

        results.phaseThreeDesign = phaseThreeDesign;
        results.effectiveSignalPhaseThree = effectiveSignalPhaseThree;

        results.tau = K + N ...
                                   + phaseThreeDesign.phaseLength;

        end
    end
end
