% Reproduces the minimum pilot-length curves in Figure 3.
function figureHandle = plotFigure3(saveToFile)

if nargin < 1
    saveToFile = false;
end

if ~(islogical(saveToFile) || isnumeric(saveToFile)) || ~isscalar(saveToFile)
    error('plotFigure3:badArguments', ...
          ['plotFigure3 takes one optional argument: ' ...
           'plotFigure3(saveToFile).  Example: plotFigure3(true).']);
end

N = 32;                 % N = 32
numberOfUsersList   = 1:16;               % K on the x-axis of Fig. 3
antennaCountList    = [8, 32];            % the two values of M in Fig. 3

benchmarkPilotLengths = PilotDesign.computePilotLengths(numberOfUsersList, N, antennaCountList(1));
benchmarkLengths = benchmarkPilotLengths.benchmark;

proposedLengths = zeros(length(antennaCountList), length(numberOfUsersList));

for antennaIndex = 1:length(antennaCountList)

    M = antennaCountList(antennaIndex);

    pilotLengths = PilotDesign.computePilotLengths(numberOfUsersList, N, M);

    proposedLengths(antennaIndex, :) = pilotLengths.total;

end

figureHandle = figure('Color', 'w', 'Position', [100, 100, 640, 480]);
hold on;
grid on;
box on;

plot(numberOfUsersList, benchmarkLengths, ...
     'Color', [0 0.7 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
     'Marker', 's', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
     'DisplayName', 'Benchmark Scheme: M=8 and M=32');

plot(numberOfUsersList, proposedLengths(1, :), ...
     'Color', [1 0 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
     'Marker', '*', 'MarkerSize', 7, ...
     'DisplayName', 'Proposed Scheme: M=8');

plot(numberOfUsersList, proposedLengths(2, :), ...
     'Color', [1 0 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
     'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
     'DisplayName', 'Proposed Scheme: M=32');

xlabel('Number of Users', 'FontSize', 11);
ylabel('Minimum Pilot Sequence Length', 'FontSize', 11);

xlim([1, 16]);
ylim([0, 600]);
set(gca, 'XTick', 1:1:16);
set(gca, 'YTick', 0:50:600);
set(gca, 'FontSize', 10);

legend('Location', 'northwest', 'FontSize', 9);

hold off;

if saveToFile

    resultsFolder = fullfile(fileparts(mfilename('fullpath')), 'Results');
    if ~exist(resultsFolder, 'dir')
        mkdir(resultsFolder);
    end

    print(figureHandle, fullfile(resultsFolder, 'Figure3.png'), '-dpng', '-r200');
    savefig(figureHandle, fullfile(resultsFolder, 'Figure3.fig'));

end

end
