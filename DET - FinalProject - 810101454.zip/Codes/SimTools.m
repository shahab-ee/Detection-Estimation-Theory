classdef SimTools
    % Small numerical helpers shared by the simulation.
    methods (Static)
        %% aggregateHeavyTailedSample
        function aggregatedValue = aggregateHeavyTailedSample(sampleVector, aggregationMode)
            
            if nargin < 2
                aggregationMode = 'trimmedMean';
            end

            switch aggregationMode

                case 'trimmedMean'
                    sortedSample    = sort(sampleVector);
                    numberKept      = max(1, floor(0.90 * length(sortedSample)));
                    aggregatedValue = mean(sortedSample(1:numberKept));

                case 'mean'
                    aggregatedValue = mean(sampleVector);

                case 'median'
                    aggregatedValue = median(sampleVector);

                otherwise
                    error('aggregateHeavyTailedSample:unknownMode', ...
                        ['aggregationMode must be ''trimmedMean'', ''mean'' or ' ...
                        '''median''.']);

            end

        end

        %% buildDftMatrix
        function dftMatrix = buildDftMatrix(numberOfRows, numberOfColumns)

            if numberOfColumns < numberOfRows
                error('buildDftMatrix:tooFewColumns', ...
                    ['A %d x %d DFT-type matrix cannot have orthogonal rows: ' ...
                    'the number of columns (%d) must be at least the number of ' ...
                    'rows (%d).'], numberOfRows, numberOfColumns, ...
                    numberOfColumns, numberOfRows);
            end

            dftMatrix = zeros(numberOfRows, numberOfColumns);

            for rowIndex = 1:numberOfRows
                for columnIndex = 1:numberOfColumns

                    reducedExponent = mod((rowIndex - 1) * (columnIndex - 1), ...
                        numberOfColumns);

                    dftMatrix(rowIndex, columnIndex) = ...
                        exp(-2 * pi * 1i * reducedExponent / numberOfColumns);

                end
            end

        end

        %% checkFigureArguments
        function checkFigureArguments(functionName, exampleCall, saveToFile, nTrials, modeString, allowedModes)

            if ~(islogical(saveToFile) || isnumeric(saveToFile)) || ~isscalar(saveToFile)
                error([functionName ':badArguments'], ...
                    ['%s: the FIRST argument must be the save flag (a logical). ' ...
                    'Correct call: %s'], functionName, exampleCall);
            end

            if ~isnumeric(nTrials) || ~isscalar(nTrials) ...
                    || nTrials < 1 || nTrials ~= floor(nTrials)
                error([functionName ':badArguments'], ...
                    ['%s: the SECOND argument must be the number of Monte Carlo ' ...
                    'trials, a positive integer.  Correct call: %s'], ...
                    functionName, exampleCall);
            end

            if nargin >= 5

                if ~(ischar(modeString) || isstring(modeString))
                    error([functionName ':badArguments'], ...
                        ['%s: the THIRD argument must be a mode string, but a %s ' ...
                        'was supplied.  This usually means the arguments were ' ...
                        'passed in the wrong order.  Correct call: %s'], ...
                        functionName, class(modeString), exampleCall);
                end

                if nargin >= 6 && ~any(strcmp(char(modeString), allowedModes))
                    allowedList = strjoin(allowedModes, ''', ''');
                    error([functionName ':badArguments'], ...
                        ['%s: unknown mode ''%s''.  Allowed values are ''%s''. ' ...
                        'Correct call: %s'], functionName, char(modeString), ...
                        allowedList, exampleCall);
                end

            end

        end

        %% convertToLinearScale
        function linearValue = convertToLinearScale(valueInDecibels, unitName)

            switch unitName

                case 'dB'
                    linearValue = 10.^(valueInDecibels / 10);

                case 'dBm'
                    linearValue = 10.^((valueInDecibels - 30) / 10);

                otherwise
                    error('convertToLinearScale:unknownUnit', ...
                        'unitName must be ''dB'' (a ratio) or ''dBm'' (a power).');

            end

        end

        %% exponentialCorrelationMatrix
        function correlationMatrix = exponentialCorrelationMatrix(matrixSize, correlationCoefficient)

            if abs(correlationCoefficient) >= 1
                error('exponentialCorrelationMatrix:badCoefficient', ...
                    'The corr coefficient must satisfy |c| < 1.');
            end

            correlationMatrix = zeros(matrixSize, matrixSize);

            for rowIndex = 1:matrixSize
                for columnIndex = 1:rowIndex
                    correlationMatrix(rowIndex, columnIndex) = ...
                        correlationCoefficient^(rowIndex - columnIndex);
                end
            end

            for rowIndex = 1:matrixSize
                for columnIndex = (rowIndex + 1):matrixSize
                    correlationMatrix(rowIndex, columnIndex) = ...
                        conj(correlationMatrix(columnIndex, rowIndex));
                end
            end

        end

        %% generateIidComplexGaussian
        function randomMatrix = generateIidComplexGaussian(numberOfRows, numberOfColumns, variancePerEntry)

            realPart      = randn(numberOfRows, numberOfColumns);
            imaginaryPart = randn(numberOfRows, numberOfColumns);

            randomMatrix = sqrt(variancePerEntry / 2) * (realPart + 1i * imaginaryPart);

        end

        %% hermitianSquareRoot
        function matrixSquareRoot = hermitianSquareRoot(hermitianMatrix)

            hermitianMatrix = (hermitianMatrix + hermitianMatrix') / 2;

            [eigenVectors, eigenValueMatrix] = eig(hermitianMatrix);
            eigenValues = real(diag(eigenValueMatrix));

            eigenValues(eigenValues < 0) = 0;

            matrixSquareRoot = eigenVectors * diag(sqrt(eigenValues)) * eigenVectors';

            matrixSquareRoot = (matrixSquareRoot + matrixSquareRoot') / 2;

        end
        %% runOverallMseTrials
        function perTrialNumerator = runOverallMseTrials(allocation, par, loss, corr, channelPool, slotAllocationMode)

            K       = par.K;
            N = par.N;
            M  = par.M;
            p  = par.p;
            sigma2     = par.sigma2;

            tau1   = allocation.tau1;
            tau2   = allocation.tau2;
            tau3 = allocation.tau3;

            phaseOneDesign = PilotDesign.buildPhaseOneDesign(K, N, ...
                tau1);
            phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, N, ...
                tau2, 1);

            phaseOneError = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
                tau1);

            noiseCovariancePhaseTwo = ChannelEstimation.computePhaseTwoNoiseCovariance( ...
                phaseTwoDesign.A(1, :).', phaseOneError.mse(1), par);

            cascadedCorrelationMatrix = IrsSystem.computeCascadedCorrelationMatrix( ...
                par, loss, corr, 1);

            schedule = PilotDesign.buildExtendedPhaseThreeSchedule(K, ...
                N, M, tau3, ...
                slotAllocationMode);

            rng(par.seed + 31415);

            nTrials    = length(channelPool);
            perTrialNumerator = zeros(nTrials, 1);

            for trialIndex = 1:nTrials

                ch = channelPool{trialIndex};

                receivedPhaseOne = IrsSystem.computeReceivedSignal(ch, ...
                    phaseOneDesign.A, phaseOneDesign.Phi, ...
                    p, sigma2);

                hHat = ChannelEstimation.estimateDirectChannelsMmse(receivedPhaseOne, ...
                    phaseOneDesign.A, loss, p, ...
                    sigma2);

                receivedPhaseTwo = IrsSystem.computeReceivedSignal(ch, ...
                    phaseTwoDesign.A, phaseTwoDesign.Phi, ...
                    p, sigma2);

                estimatedTypicalCascaded = ChannelEstimation.estimateTypicalCascadedLmmse(receivedPhaseTwo, ...
                    hHat, phaseTwoDesign.A, ...
                    phaseTwoDesign.Phi, noiseCovariancePhaseTwo, ...
                    cascadedCorrelationMatrix, p);

                trueTypicalCascaded = ch.g(:, :, 1);

                accumulatedError = sum(sum(abs(hHat ...
                    - ch.h).^2)) ...
                    + sum(sum(abs(estimatedTypicalCascaded - trueTypicalCascaded).^2));

                for k = 2:K

                    phaseThreeStatistics = ChannelEstimation.computePhaseThreeStatistics(k, ...
                        [], loss, corr, par, tau1);
                    noiseCovariancePhaseThree = phaseThreeStatistics.noiseCovariance;

                    trueRatios = ch.lambda(:, k);

                    slotsForThisUser = schedule.slotsPerUser(k - 1);

                    observedSignals     = zeros(M, slotsForThisUser);
                    reflectionPhaseList = cell(1, slotsForThisUser);

                    for slotIndex = 1:slotsForThisUser

                        reflectionPhases = schedule.reflectionPhases{k, slotIndex};
                        reflectionPhaseList{slotIndex} = reflectionPhases;

                        phaseThreeNoise = SimTools.generateIidComplexGaussian( ...
                            M, 1, sigma2);

                        observedSignals(:, slotIndex) = sqrt(p) ...
                            * (trueTypicalCascaded .* reflectionPhases) * trueRatios ...
                            + sqrt(p) ...
                            * (ch.h(:, k) ...
                            - hHat(:, k)) ...
                            + phaseThreeNoise;

                    end

                    estimatedRatios = ChannelEstimation.estimateRatiosOverSlots(observedSignals, ...
                        estimatedTypicalCascaded, reflectionPhaseList, ...
                        noiseCovariancePhaseThree, p, ...
                        schedule.combineMode);

                    estimatedCascaded = estimatedTypicalCascaded .* estimatedRatios.';
                    trueCascaded      = ch.g(:, :, k);

                    accumulatedError = accumulatedError ...
                        + sum(sum(abs(estimatedCascaded - trueCascaded).^2));

                end

                perTrialNumerator(trialIndex) = accumulatedError;

            end

        end
    end
end
