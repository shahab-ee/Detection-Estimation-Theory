% Runs the three-phase estimator and reproduces Figures 3-7.
clear;
clc;

par  = IrsSystem.getSystemParameters();
rng(par.seed);

pos    = IrsSystem.generateUserPositions(par);
loss    = IrsSystem.computePathLosses(par, pos);
corr = IrsSystem.buildCorrelationMatrices(par);

ch    = IrsSystem.generateChannelRealization(par, loss, corr);

fprintf('\n===================== SYSTEM MODEL =====================\n');
fprintf('M = %d antennas , N = %d IRS elements , K = %d users\n', ...
    par.M, par.N, ...
    par.K);
fprintf('p = %.1f dBm , sigma^2 = %.1f dBm\n', ...
    par.pDbm, par.sigma2Dbm);
fprintf('Channel coefficients to estimate, K M N + K M = %d\n', ...
    par.K * par.M ...
    * par.N ...
    + par.K * par.M);

noiselessResults = ChannelEstimation.runNoiselessThreePhase(par, ch);

minimumLengths = PilotDesign.computePilotLengths(par.K, ...
    par.N, par.M);

directErrorNoiseless = norm(noiselessResults.hHat ...
    - ch.h, 'fro') / norm(ch.h, 'fro');

cascadedErrorNoiseless = 0;
for k = 1:par.K
    trueSlice      = ch.g(:, :, k);
    estimatedSlice = noiselessResults.gHat(:, :, k);
    cascadedErrorNoiseless = max(cascadedErrorNoiseless, ...
        norm(estimatedSlice - trueSlice, 'fro') / norm(trueSlice, 'fro'));
end

fprintf('\n============ NOISELESS PROTOCOL (Section IV) ============\n');
fprintf('tau = tau_1 + tau_2 + tau_3 = %d + %d + %d = %d  (eq. 62)\n', ...
    minimumLengths.phaseOne, minimumLengths.phaseTwo, ...
    minimumLengths.phaseThree, minimumLengths.total);
fprintf('Benchmark would need K + K N = %d symbols\n', ...
    minimumLengths.benchmark);
fprintf('Direct channel   error : %.3e  \n', directErrorNoiseless);
fprintf('Reflected channel error: %.3e  \n', cascadedErrorNoiseless);

noisyEstimates = ChannelEstimation.runThreePhaseProtocol(ch, par, loss, ...
    corr);

directErrorNoisy = sum(sum(abs(noisyEstimates.h - ch.h).^2)) ...
    / sum(sum(abs(ch.h).^2));

cascadedErrorNoisy = sum(sum(sum(abs(noisyEstimates.g - ch.g).^2))) ...
    / sum(sum(sum(abs(ch.g).^2)));

fprintf('\n============== NOISY PROTOCOL (Table I) ================\n');
fprintf('tau_1 = %d , tau_2 = %d , tau_3 = %d , total = %d\n', ...
    noisyEstimates.allocation.tau1, ...
    noisyEstimates.allocation.tau2, ...
    noisyEstimates.allocation.tau3, ...
    noisyEstimates.tau);
fprintf('Normalized error, direct ch    : %.4e\n', directErrorNoisy);
fprintf('Normalized error, reflected ch : %.4e\n', cascadedErrorNoisy);
fprintf('(single realization, so these values fluctuate)\n');

%% Figures 3-7
figureStart = tic;

fprintf('\n============== REGENERATING FIGURES 3-7 ==============\n');

plotFigure3(true);
plotFigure4(true, 1200, 'singleSweep');
plotFigure5(true, 1200, 'trimmedMean', 15);
plotFigure6(true, 1200, 'averageEstimates');
plotFigure7(true, 1200, 'unused', 10);

fprintf('\nAll figures were written to Results/ in %.1f seconds.\n\n', ...
    toc(figureStart));
