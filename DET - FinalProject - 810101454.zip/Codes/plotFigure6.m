% Reproduces the proposed and benchmark Phase-III curves in Figure 6.
function [figureHandle, results] = plotFigure6(saveToFile, nTrials, slotAllocationMode)

if nargin < 1, saveToFile = false;             end
if nargin < 2, nTrials = 1200;           end
if nargin < 3, slotAllocationMode = 'averageEstimates';  end

SimTools.checkFigureArguments('plotFigure6', ...
    'plotFigure6(true, 600, ''repeat'')', ...
    saveToFile, nTrials, slotAllocationMode, ...
    {'averageEstimates', 'jointLeastSquares', 'repeat'});

[par, ~, loss, corr] = IrsSystem.buildNumericalExampleScenario(15);

N = par.N;
M  = par.M;
K       = par.K;
p  = par.p;
sigma2     = par.sigma2;

tau1 = K;
tau2 = N;

phaseOneDesign = PilotDesign.buildPhaseOneDesign(K, N, ...
    tau1);
phaseOneError  = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
    tau1);
phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, N, ...
    tau2, 1);

cascadedCorrelationMatrix = IrsSystem.computeCascadedCorrelationMatrix( ...
    par, loss, corr, 1);

noiseCovariancePhaseTwo = ChannelEstimation.computePhaseTwoNoiseCovariance( ...
    phaseTwoDesign.A(1, :).', phaseOneError.mse(1), par);

rng(par.seed);

realizationPool = cell(nTrials, 1);

for trialIndex = 1:nTrials

    ch = IrsSystem.generateChannelRealization(par, loss, corr);

    receivedPhaseOne = IrsSystem.computeReceivedSignal(ch, ...
        phaseOneDesign.A, phaseOneDesign.Phi, ...
        p, sigma2);
    hHat = ChannelEstimation.estimateDirectChannelsMmse(receivedPhaseOne, ...
        phaseOneDesign.A, loss, p, ...
        sigma2);

    receivedPhaseTwo = IrsSystem.computeReceivedSignal(ch, ...
        phaseTwoDesign.A, phaseTwoDesign.Phi, ...
        p, sigma2);
    estimatedTypicalCascaded = ChannelEstimation.estimateTypicalCascadedLmmse(receivedPhaseTwo, ...
        hHat, phaseTwoDesign.A, ...
        phaseTwoDesign.Phi, noiseCovariancePhaseTwo, ...
        cascadedCorrelationMatrix, p);

    onePoolEntry.ch                 = ch;
    onePoolEntry.hHat   = hHat;
    onePoolEntry.estimatedTypicalCascaded = estimatedTypicalCascaded;

    realizationPool{trialIndex} = onePoolEntry;

end

phaseThreeLengthList = [7, 12, 17, 22, 27, 32];
numberOfPoints       = length(phaseThreeLengthList);

normalizedMseBenchmark = zeros(1, numberOfPoints);
benchmarkRankFloor     = zeros(1, numberOfPoints);
normalizedMseProposed  = zeros(1, numberOfPoints);

for pointIndex = 1:numberOfPoints

    tau3 = phaseThreeLengthList(pointIndex);

    benchmarkDesign = PilotDesign.buildBenchmarkPhaseThreeDesign(K, ...
        N, tau3);

    benchmarkError = ChannelEstimation.computeBenchmarkPhaseThreeMse(benchmarkDesign, ...
        loss, corr, par, tau1);

    normalizedMseBenchmark(pointIndex) = benchmarkError.normalizedMse;
    benchmarkRankFloor(pointIndex)     = benchmarkError.rankFloor;

    schedule = PilotDesign.buildExtendedPhaseThreeSchedule(K, ...
        N, M, tau3, ...
        slotAllocationMode);

    rng(par.seed + 999);

    perTrialError      = zeros(nTrials, 1);
    perTrialRatioPower = zeros(nTrials, 1);

    for trialIndex = 1:nTrials

        onePoolEntry = realizationPool{trialIndex};
        ch     = onePoolEntry.ch;

        trueTypicalCascaded      = ch.g(:, :, 1);
        estimatedTypicalCascaded = onePoolEntry.estimatedTypicalCascaded;
        hHat   = onePoolEntry.hHat;

        accumulatedError = 0;
        accumulatedPower = 0;

        for k = 2:K

            phaseThreeStatistics = ChannelEstimation.computePhaseThreeStatistics(k, ...
                [], loss, corr, par, tau1);
            noiseCovariancePhaseThree = phaseThreeStatistics.noiseCovariance;

            trueRatios = ch.lambda(:, k);

            slotsForThisUser = schedule.slotsPerUser(k - 1);

            observedSignals     = zeros(M, slotsForThisUser);
            reflectionPhaseList = cell(1, slotsForThisUser);

            for slotIndex = 1:slotsForThisUser

                reflectionPhases = schedule.reflectionPhases{k, slotIndex};
                reflectionPhaseList{slotIndex} = reflectionPhases;

                rotatedTrueMatrix = trueTypicalCascaded .* reflectionPhases;

                phaseThreeNoise = SimTools.generateIidComplexGaussian( ...
                    M, 1, sigma2);

                observedSignals(:, slotIndex) = ...
                    sqrt(p) * rotatedTrueMatrix * trueRatios ...
                    + sqrt(p) ...
                    * (ch.h(:, k) ...
                    - hHat(:, k)) ...
                    + phaseThreeNoise;

            end

            estimatedRatios = ChannelEstimation.estimateRatiosOverSlots(observedSignals, ...
                estimatedTypicalCascaded, reflectionPhaseList, ...
                noiseCovariancePhaseThree, p, ...
                schedule.combineMode);

            accumulatedError = accumulatedError ...
                + sum(abs(estimatedRatios - trueRatios).^2);
            accumulatedPower = accumulatedPower + sum(abs(trueRatios).^2);

        end

        perTrialError(trialIndex)      = accumulatedError;
        perTrialRatioPower(trialIndex) = accumulatedPower;

    end

    normalizedMseProposed(pointIndex) = ...
        SimTools.aggregateHeavyTailedSample(perTrialError) / SimTools.aggregateHeavyTailedSample(perTrialRatioPower);


end

figureHandle = figure('Color', 'w', 'Position', [100, 100, 640, 480]);
hold on; grid on; box on;

semilogy(phaseThreeLengthList, normalizedMseBenchmark, ...
    'Color', [1 0 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Benchmark Scheme');

semilogy(phaseThreeLengthList, normalizedMseProposed, ...
    'Color', [0 0.7 0], 'LineStyle', '-', 'LineWidth', 1.4, ...
    'Marker', 'none', ...
    'DisplayName', 'Proposed Solution: with Imperfect g_{1,n}');

set(gca, 'YScale', 'log');
xlabel('Pilot Sequence Length in Phase III', 'FontSize', 11);
ylabel('Normalized MSE', 'FontSize', 11);
xlim([7, 32]); ylim([1e-3, 1e0]);
set(gca, 'XTick', phaseThreeLengthList);
set(gca, 'YTick', 10.^(-3:0));
set(gca, 'FontSize', 10);
legend('Location', 'east', 'FontSize', 9);
hold off;

results.phaseThreeLengthList    = phaseThreeLengthList;
results.normalizedMseBenchmark  = normalizedMseBenchmark;
results.benchmarkRankFloor      = benchmarkRankFloor;
results.normalizedMseProposed   = normalizedMseProposed;
results.slotAllocationMode      = slotAllocationMode;
results.nTrials          = nTrials;

if saveToFile
    resultsFolder = fullfile(fileparts(mfilename('fullpath')), 'Results');
    if ~exist(resultsFolder, 'dir'), mkdir(resultsFolder); end
    print(figureHandle, fullfile(resultsFolder, 'Figure6.png'), '-dpng', '-r200');
    savefig(figureHandle, fullfile(resultsFolder, 'Figure6.fig'));
    save(fullfile(resultsFolder, 'Figure6.mat'), 'results');
end

end
