classdef PilotDesign
    % Pilot and IRS reflection designs from Sections IV and V.
    methods (Static)
        %% computePilotLengths
        function pilotLengths = computePilotLengths(K, N, M)

        pilotLengths.phaseOne = K;

        pilotLengths.phaseTwo = N * ones(size(K));

        theoremOneTerm = K - 1;
        theoremTwoTerm = ceil((K - 1) * N ...
                              / M);

        pilotLengths.phaseThree = max(theoremOneTerm, theoremTwoTerm);

        pilotLengths.total = pilotLengths.phaseOne ...
                             + pilotLengths.phaseTwo ...
                             + pilotLengths.phaseThree;

        pilotLengths.massiveMimoLimit = 2 * K + N - 1;

        pilotLengths.benchmark = K ...
                                 + K * N;

        end

        %% allocateExtraPilotSymbols
        function allocation = allocateExtraPilotSymbols(K, N, M, tau, allocationPolicy)

        if nargin < 5
            allocationPolicy = 'allToPhaseTwo';
        end

        minimumPhaseOne   = K;
        minimumPhaseTwo   = N;
        minimumPhaseThree = (K - 1) ...
                            * ceil(N / M);

        minimumTotal = minimumPhaseOne + minimumPhaseTwo + minimumPhaseThree;

        if tau < minimumTotal
            error('allocateExtraPilotSymbols:budgetTooSmall', ...
                  ['The total budget must be at least the minimum of eq. (62), ' ...
                   'which is %d, but tau = %d was requested.'], ...
                  minimumTotal, tau);
        end

        extraSymbols = tau - minimumTotal;

        switch allocationPolicy

            case 'allToPhaseOne'
                allocation.tau1   = minimumPhaseOne + extraSymbols;
                allocation.tau2   = minimumPhaseTwo;
                allocation.tau3 = minimumPhaseThree;

            case 'allToPhaseTwo'
                allocation.tau1   = minimumPhaseOne;
                allocation.tau2   = minimumPhaseTwo + extraSymbols;
                allocation.tau3 = minimumPhaseThree;

            case 'evenlySplit'
                shareForPhaseOne   = floor(extraSymbols / 3);
                shareForPhaseThree = floor(extraSymbols / 3);
                shareForPhaseTwo   = extraSymbols - shareForPhaseOne ...
                                     - shareForPhaseThree;

                allocation.tau1   = minimumPhaseOne   + shareForPhaseOne;
                allocation.tau2   = minimumPhaseTwo   + shareForPhaseTwo;
                allocation.tau3 = minimumPhaseThree + shareForPhaseThree;

            otherwise
                error('allocateExtraPilotSymbols:unknownPolicy', ...
                      ['allocationPolicy must be ''allToPhaseOne'', ' ...
                       '''allToPhaseTwo'' or ''evenlySplit''.']);

        end

        allocation.extraSymbols = extraSymbols;
        allocation.policy       = allocationPolicy;

        end

        %% buildPhaseOneDesign
        function phaseOneDesign = buildPhaseOneDesign(K, N, tau1)

        if tau1 < K
            error('buildPhaseOneDesign:phaseTooShort', ...
                  ['Phase I needs tau_1 >= K to build K orthogonal pilot ' ...
                   'sequences (eq. (24)), but tau_1 = %d and K = %d.'], ...
                  tau1, K);
        end

        phaseOneDesign.A = SimTools.buildDftMatrix(K, tau1);

        phaseOneDesign.Phi = zeros(N, tau1);

        phaseOneDesign.phaseLength = tau1;

        end

        %% buildPhaseTwoDesign
        function phaseTwoDesign = buildPhaseTwoDesign(K, N, tau2, typicalUserIndex)

        if nargin < 4
            typicalUserIndex = 1;
        end

        if tau2 < N
            error('buildPhaseTwoDesign:phaseTooShort', ...
                  ['Phase II needs tau_2 >= N for rank(Phi^II) = N ' ...
                   '(eq. (32)), but tau_2 = %d and N = %d.'], ...
                  tau2, N);
        end

        phaseTwoDesign.A = zeros(K, tau2);
        phaseTwoDesign.A(typicalUserIndex, :) = ones(1, tau2);

        phaseTwoDesign.Phi = SimTools.buildDftMatrix(N, ...
                                                         tau2);

        phaseTwoDesign.phaseLength      = tau2;
        phaseTwoDesign.typicalUserIndex = typicalUserIndex;

        end

        %% buildPhaseThreeDesignNoiseless
        function phaseThreeDesign = buildPhaseThreeDesignNoiseless(K, N, M)

        if M >= N

            phaseThreeDesign = PilotDesign.buildTheoremOneDesign(K, ...
                N);
            phaseThreeDesign.theorem = 1;

        else

            phaseThreeDesign = PilotDesign.buildTheoremTwoDesign(K, ...
                N, M);
            phaseThreeDesign.theorem = 2;

        end

        end

        function phaseThreeDesign = buildTheoremOneDesign(K, N)

        tau3 = K - 1;

        phaseThreeDesign.A = zeros(K, tau3);

        for localTimeIndex = 1:tau3

            activeUserIndex = localTimeIndex + 1;
            phaseThreeDesign.A(activeUserIndex, localTimeIndex) = 1;

        end

        phaseThreeDesign.Phi = ones(N, tau3);

        phaseThreeDesign.phaseLength = tau3;

        end

        function phaseThreeDesign = buildTheoremTwoDesign(K, N, M)

        sets = PilotDesign.computeTheoremTwoSets(K, N, ...
                                     M);

        tau3 = sets.tau3;

        phaseThreeDesign.A      = zeros(K, tau3);
        phaseThreeDesign.Phi = zeros(N, tau3);

        for slotIndex = 1:sets.firstRegimeLength

            activeUserIndex = sets.firstRegimeUser(slotIndex);
            phaseThreeDesign.A(activeUserIndex, slotIndex) = 1;

            activeElements = sets.omegaSet{slotIndex};
            for positionIndex = 1:length(activeElements)
                n = activeElements(positionIndex);
                phaseThreeDesign.Phi(n, slotIndex) = 1;
            end

        end

        for slotIndex = (sets.firstRegimeLength + 1):tau3

            activeUsers = sets.kSet{slotIndex};
            for positionIndex = 1:length(activeUsers)
                activeUserIndex = activeUsers(positionIndex);
                phaseThreeDesign.A(activeUserIndex, slotIndex) = 1;
            end

            activeElements = sets.nSet{slotIndex};
            for positionIndex = 1:length(activeElements)
                n = activeElements(positionIndex);
                phaseThreeDesign.Phi(n, slotIndex) = 1;
            end

        end

        phaseThreeDesign.phaseLength = tau3;
        phaseThreeDesign.sets        = sets;

        end

        %% buildPhaseThreeDesignOrthogonal
        function phaseThreeDesign = buildPhaseThreeDesignOrthogonal(K, N, M)

        slotsPerUser = ceil(N / M);

        tau3 = (K - 1) * slotsPerUser;

        phaseThreeDesign.A      = zeros(K, tau3);
        phaseThreeDesign.Phi = zeros(N, tau3);
        phaseThreeDesign.activeUser       = zeros(tau3, 1);
        phaseThreeDesign.activeElements   = cell(tau3, 1);

        for localSlotIndex = 1:tau3

            activeUserIndex = ceil(localSlotIndex / slotsPerUser) + 1;

            positionInBlock = mod(localSlotIndex - 1, slotsPerUser) + 1;

            if positionInBlock < slotsPerUser

                elementOffset  = (positionInBlock - 1) * M;
                activeElements = (elementOffset + 1):(elementOffset + M);

            else

                firstLeftoverElement = (slotsPerUser - 1) * M + 1;
                activeElements = firstLeftoverElement:N;

            end

            phaseThreeDesign.A(activeUserIndex, localSlotIndex) = 1;

            for positionIndex = 1:length(activeElements)
                n = activeElements(positionIndex);
                phaseThreeDesign.Phi(n, localSlotIndex) = 1;
            end

            phaseThreeDesign.activeUser(localSlotIndex)     = activeUserIndex;
            phaseThreeDesign.activeElements{localSlotIndex} = activeElements;

        end

        phaseThreeDesign.phaseLength  = tau3;
        phaseThreeDesign.slotsPerUser = slotsPerUser;

        end

        %% computeTheoremTwoSets
        function sets = computeTheoremTwoSets(K, N, M)

        if M >= N
            error('computeTheoremTwoSets:caseNotApplicable', ...
                  ['Theorem 2 is stated for M < N, but M = %d and N = %d. ' ...
                   'Use the Theorem 1 design (Part 4) instead.'], ...
                  M, N);
        end

        sets.rho     = floor(N / M);
        sets.upsilon = N - M * sets.rho;

        sets.tau3 = ceil((K - 1) * N ...
                                     / M);
        sets.firstRegimeLength = (K - 1) * sets.rho;

        sets.tSet         = cell(K, 1);
        sets.lambdaSetTwo = cell(K, 1);
        sets.lambdaSetOne = cell(K, 1);

        for k = 2:K

            firstElementOfT = (k - 2) * sets.upsilon + 1;
            lastElementOfT  = (k - 1) * sets.upsilon;
            setT = firstElementOfT:lastElementOfT;      % empty when upsilon = 0

            setLambdaTwo = zeros(1, length(setT));
            for positionIndex = 1:length(setT)
                valueOfM = setT(positionIndex);
                setLambdaTwo(positionIndex) = valueOfM ...
                    - (ceil(valueOfM / N) - 1) * N;
            end

            setLambdaOne = setdiff(1:N, setLambdaTwo);

            sets.tSet{k}         = setT;
            sets.lambdaSetTwo{k} = setLambdaTwo;
            sets.lambdaSetOne{k} = setLambdaOne;

        end

        sets.omegaSet        = cell(sets.firstRegimeLength, 1);
        sets.firstRegimeUser = zeros(sets.firstRegimeLength, 1);

        for slotIndex = 1:sets.firstRegimeLength

            userCounter = ceil(slotIndex / sets.rho);
            activeUserIndex = userCounter + 1;

            offsetKappa = (slotIndex - (userCounter - 1) * sets.rho - 1) ...
                          * M;

            setLambdaOne = sets.lambdaSetOne{activeUserIndex};

            sets.omegaSet{slotIndex} = ...
                setLambdaOne((offsetKappa + 1):(offsetKappa + M));

            sets.firstRegimeUser(slotIndex) = activeUserIndex;

        end

        totalSecondRegimeUnknowns = (K - 1) * sets.upsilon;

        sets.jSet             = cell(sets.tau3, 1);
        sets.kSet             = cell(sets.tau3, 1);
        sets.nSet             = cell(sets.tau3, 1);
        sets.secondRegimeUser = cell(sets.tau3, 1);

        for slotIndex = (sets.firstRegimeLength + 1):sets.tau3

            slotCounter = slotIndex - sets.firstRegimeLength;
            firstUnknownIndex = (slotCounter - 1) * M + 1;
            lastUnknownIndex  = min(slotCounter * M, ...
                                    totalSecondRegimeUnknowns);
            setJ = firstUnknownIndex:lastUnknownIndex;

            numberOfUnknownsHere = length(setJ);
            userOfEachUnknown    = zeros(1, numberOfUnknownsHere);
            elementOfEachUnknown = zeros(1, numberOfUnknownsHere);

            for positionIndex = 1:numberOfUnknownsHere

                globalUnknownIndex = setJ(positionIndex);

                userCounter     = ceil(globalUnknownIndex / sets.upsilon);
                activeUserIndex = userCounter + 1;

                localPosition = globalUnknownIndex ...
                                - (userCounter - 1) * sets.upsilon;

                userOfEachUnknown(positionIndex)    = activeUserIndex;
                elementOfEachUnknown(positionIndex) = ...
                    sets.lambdaSetTwo{activeUserIndex}(localPosition);

            end

            sets.jSet{slotIndex}             = setJ;
            sets.kSet{slotIndex}             = unique(userOfEachUnknown);
            sets.nSet{slotIndex}             = elementOfEachUnknown;
            sets.secondRegimeUser{slotIndex} = userOfEachUnknown;

        end

        end

        %% buildExtendedPhaseThreeSchedule
        function schedule = buildExtendedPhaseThreeSchedule(K, N, M, tau3, slotAllocationMode)

        if nargin < 5
            slotAllocationMode = 'averageEstimates';
        end

        minimumLength = (K - 1) ...
                        * ceil(N / M);

        if tau3 < minimumLength
            error('buildExtendedPhaseThreeSchedule:budgetTooSmall', ...
                  ['Phase III needs at least (K-1)*ceil(N/M) = %d slots, but ' ...
                   'tau_3 = %d was requested.'], minimumLength, tau3);
        end

        numberOfActiveUsers = K - 1;

        if strcmp(slotAllocationMode, 'unused')

            slotsPerUserMinimum = ceil(N / M);
            schedule.slotsPerUser = slotsPerUserMinimum ...
                                    * ones(numberOfActiveUsers, 1);

        else

            baseSlotsPerUser = floor(tau3 / numberOfActiveUsers);
            leftoverSlots    = mod(tau3, numberOfActiveUsers);

            schedule.slotsPerUser = baseSlotsPerUser * ones(numberOfActiveUsers, 1);
            schedule.slotsPerUser(1:leftoverSlots) = baseSlotsPerUser + 1;

        end

        maximumSlots = max(schedule.slotsPerUser);
        schedule.reflectionPhases = cell(K, maximumSlots);

        for k = 2:K

            slotsForThisUser = schedule.slotsPerUser(k - 1);

            for slotIndex = 1:slotsForThisUser

                if slotIndex == 1 || any(strcmp(slotAllocationMode, ...
                                                {'repeat', 'unused'}))

                    reflectionPhases = ones(1, N);

                else

                    reflectionPhases = ...
                        exp(1i * 2 * pi * rand(1, N));

                end

                schedule.reflectionPhases{k, slotIndex} = reflectionPhases;

            end

        end

        switch slotAllocationMode
            case 'averageEstimates'
                schedule.combineMode = 'average';
            case {'jointLeastSquares', 'repeat', 'unused'}
                schedule.combineMode = 'joint';
            otherwise
                error('buildExtendedPhaseThreeSchedule:unknownMode', ...
                      ['slotAllocationMode must be ''averageEstimates'', ' ...
                       '''jointLeastSquares'', ''repeat'' or ''unused''.']);
        end

        schedule.phaseLength        = tau3;
        schedule.slotAllocationMode = slotAllocationMode;

        end

        %% buildBenchmarkPhaseThreeDesign
        function benchmarkDesign = buildBenchmarkPhaseThreeDesign(K, N, tau3)

        numberOfActiveUsers = K - 1;

        baseSymbolsPerUser = floor(tau3 / numberOfActiveUsers);
        leftoverSymbols    = mod(tau3, numberOfActiveUsers);

        symbolsPerUser = baseSymbolsPerUser * ones(numberOfActiveUsers, 1);
        symbolsPerUser(1:leftoverSymbols) = baseSymbolsPerUser + 1;
        symbolsPerUser = max(symbolsPerUser, 1);

        benchmarkDesign.symbolsPerUser = symbolsPerUser;

        fullDftMatrix = SimTools.buildDftMatrix(N, N);

        benchmarkDesign.Phi = cell(numberOfActiveUsers, 1);

        for userCounter = 1:numberOfActiveUsers
            numberOfColumns = min(symbolsPerUser(userCounter), N);
            benchmarkDesign.Phi{userCounter} = ...
                fullDftMatrix(:, 1:numberOfColumns);
        end

        benchmarkDesign.phaseLength = tau3;

        end

        %% buildComparisonReflectionMatrix
        function Phi = buildComparisonReflectionMatrix(N, phaseLength, schemeName, sweepMode)

        if nargin < 4
            sweepMode = 'cyclic';
        end

        switch schemeName

            case 'onOff'

                if phaseLength < N
                    error('buildComparisonReflectionMatrix:phaseTooShort', ...
                          ['The on/off scheme needs tau_2 >= N so that every ' ...
                           'element is switched on at least once, but tau_2 = ' ...
                           '%d and N = %d.'], phaseLength, N);
                end

                Phi = zeros(N, phaseLength);

                switch sweepMode

                    case 'cyclic'
                        for i = 1:phaseLength
                            activeElementIndex = ...
                                mod(i - 1, N) + 1;
                            Phi(activeElementIndex, i) = 1;
                        end

                    case 'singleSweep'
                        for n = 1:N
                            Phi(n, n) = 1;
                        end

                    otherwise
                        error('buildComparisonReflectionMatrix:unknownSweepMode', ...
                              'sweepMode must be ''cyclic'' or ''singleSweep''.');

                end

            case 'randomPhase'

                randomPhases = 2 * pi * rand(N, phaseLength);
                Phi = exp(1i * randomPhases);

            otherwise
                error('buildComparisonReflectionMatrix:unknownScheme', ...
                      'schemeName must be ''onOff'' or ''randomPhase''.');

        end

        end
    end
end
