% Reproduces the overall normalized-MSE allocation comparison in Figure 7.
function [figureHandle, results] = plotFigure7(saveToFile, nTrials, slotAllocationMode, typicalUserDistanceToIrs)

if nargin < 1, saveToFile = false;   end
if nargin < 2, nTrials = 1200; end
if nargin < 3, slotAllocationMode = 'unused'; end
if nargin < 4, typicalUserDistanceToIrs = 10; end

SimTools.checkFigureArguments('plotFigure7', ...
    'plotFigure7(true, 500, ''unused'', 10)', ...
    saveToFile, nTrials, slotAllocationMode, ...
    {'unused', 'repeat', 'averageEstimates', 'jointLeastSquares'});

[par, ~, loss, corr] = ...
    IrsSystem.buildNumericalExampleScenario(typicalUserDistanceToIrs);

K       = par.K;
N = par.N;
M  = par.M;

totalChannelPower = M * sum(loss.betaBU);
for k = 1:K
    totalChannelPower = totalChannelPower + real(trace( ...
        IrsSystem.computeCascadedCorrelationMatrix(par, loss, ...
        corr, k)));
end

rng(par.seed);

channelPool = cell(nTrials, 1);
for trialIndex = 1:nTrials
    channelPool{trialIndex} = IrsSystem.generateChannelRealization(par, ...
        loss, corr);
end

totalPilotLengthList = 50:10:100;
numberOfPoints       = length(totalPilotLengthList);

policyList = {'allToPhaseOne', 'allToPhaseTwo', 'evenlySplit'};

normalizedMseBenchmark = zeros(1, numberOfPoints);
normalizedMseProposed  = zeros(length(policyList), numberOfPoints);

for pointIndex = 1:numberOfPoints

    tau = totalPilotLengthList(pointIndex);

    benchmarkError = ChannelEstimation.computeBenchmarkOverallMse(tau, ...
        loss, corr, par);
    normalizedMseBenchmark(pointIndex) = benchmarkError.normalizedMse;

    for policyIndex = 1:length(policyList)

        allocation = PilotDesign.allocateExtraPilotSymbols(K, ...
            N, M, tau, ...
            policyList{policyIndex});

        perTrialNumerator = SimTools.runOverallMseTrials(allocation, par, ...
            loss, corr, channelPool, slotAllocationMode);

        normalizedMseProposed(policyIndex, pointIndex) = ...
            SimTools.aggregateHeavyTailedSample(perTrialNumerator) / totalChannelPower;

    end


end

figureHandle = figure('Color', 'w', 'Position', [100, 100, 640, 480]);
hold on; grid on; box on;

semilogy(totalPilotLengthList, normalizedMseBenchmark, ...
    'Color', [1 0 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Benchmark Scheme');

semilogy(totalPilotLengthList, normalizedMseProposed(1, :), ...
    'Color', [0.55 0.27 0.07], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 'v', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Allocating All Extra Symbols to Phase I');

semilogy(totalPilotLengthList, normalizedMseProposed(2, :), ...
    'Color', [0 0.7 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 's', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Allocating All Extra Symbols to Phase II');

semilogy(totalPilotLengthList, normalizedMseProposed(3, :), ...
    'Color', [0 0 1], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 'x', 'MarkerSize', 8, ...
    'DisplayName', 'Evenly Allocating Extra Symbols to Phases I, II, III');

set(gca, 'YScale', 'log');
xlabel('Overall Pilot Sequence Length', 'FontSize', 11);
ylabel('Normalized MSE', 'FontSize', 11);
xlim([50, 100]); ylim([1e-3, 1e0]);
set(gca, 'XTick', totalPilotLengthList);
set(gca, 'YTick', 10.^(-3:0));
set(gca, 'FontSize', 10);
legend('Location', 'east', 'FontSize', 8);
hold off;

results.totalPilotLengthList   = totalPilotLengthList;
results.normalizedMseBenchmark = normalizedMseBenchmark;
results.normalizedMseProposed  = normalizedMseProposed;
results.policyList             = policyList;
results.nTrials         = nTrials;
results.slotAllocationMode     = slotAllocationMode;
results.typicalUserDistanceToIrs = typicalUserDistanceToIrs;

if saveToFile
    resultsFolder = fullfile(fileparts(mfilename('fullpath')), 'Results');
    if ~exist(resultsFolder, 'dir'), mkdir(resultsFolder); end
    print(figureHandle, fullfile(resultsFolder, 'Figure7.png'), '-dpng', '-r200');
    savefig(figureHandle, fullfile(resultsFolder, 'Figure7.fig'));
    save(fullfile(resultsFolder, 'Figure7.mat'), 'results');
end

end