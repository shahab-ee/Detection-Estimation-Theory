% Reproduces the Phase-III theory and Monte Carlo curves in Figure 5.
function [figureHandle, results] = plotFigure5(saveToFile, nTrials, aggregationMode, typicalUserDistanceToIrs)

if nargin < 1, saveToFile = false;                end
if nargin < 2, nTrials = 1200;             end
if nargin < 3, aggregationMode = 'trimmedMean';   end
if nargin < 4, typicalUserDistanceToIrs = 15;     end

SimTools.checkFigureArguments('plotFigure5', ...
    'plotFigure5(true, 1200, ''trimmedMean'', 15)', ...
    saveToFile, nTrials, aggregationMode, ...
    {'trimmedMean', 'mean', 'median'});

if ~isnumeric(typicalUserDistanceToIrs) || ~isscalar(typicalUserDistanceToIrs)
    error('plotFigure5:badArguments', ...
        'typicalUserDistanceToIrs must be a numeric scalar in metres.');
end

[par, ~, loss, corr] = ...
    IrsSystem.buildNumericalExampleScenario(typicalUserDistanceToIrs);

N = par.N;
M  = par.M;
K       = par.K;
p  = par.p;
sigma2     = par.sigma2;

tau1 = K;
phaseOneDesign = PilotDesign.buildPhaseOneDesign(K, N, ...
    tau1);
phaseOneError  = ChannelEstimation.computePhaseOneMse(loss, corr, par, ...
    tau1);

phaseThreeDesign = PilotDesign.buildPhaseThreeDesignOrthogonal(K, ...
    N, M);

cascadedCorrelationMatrix = IrsSystem.computeCascadedCorrelationMatrix( ...
    par, loss, corr, 1);

rng(par.seed);

realizationPool = cell(nTrials, 1);

for trialIndex = 1:nTrials

    ch = IrsSystem.generateChannelRealization(par, loss, corr);

    receivedPhaseOne = IrsSystem.computeReceivedSignal(ch, ...
        phaseOneDesign.A, phaseOneDesign.Phi, ...
        p, sigma2);

    hHat = ChannelEstimation.estimateDirectChannelsMmse( ...
        receivedPhaseOne, phaseOneDesign.A, loss, ...
        p, sigma2);

    phaseThreeNoise = SimTools.generateIidComplexGaussian(M, ...
        phaseThreeDesign.phaseLength, sigma2);

    onePoolEntry.ch               = ch;
    onePoolEntry.hHat = hHat;
    onePoolEntry.phaseThreeNoise        = phaseThreeNoise;

    realizationPool{trialIndex} = onePoolEntry;

end

phaseTwoLengthList = 32:4:64;
numberOfPoints     = length(phaseTwoLengthList);

normalizedMseTheory          = zeros(1, numberOfPoints);
normalizedMsePerfectCascaded = zeros(1, numberOfPoints);
normalizedMseImperfect       = zeros(1, numberOfPoints);

for pointIndex = 1:numberOfPoints

    tau2 = phaseTwoLengthList(pointIndex);

    rng(par.seed + 4242);

    phaseTwoDesign = PilotDesign.buildPhaseTwoDesign(K, ...
        N, tau2, 1);

    typicalUserPilot = phaseTwoDesign.A(1, :).';

    noiseCovariancePhaseTwo = ChannelEstimation.computePhaseTwoNoiseCovariance( ...
        typicalUserPilot, phaseOneError.mse(1), par);

    perTrialTheory     = zeros(nTrials, 1);
    perTrialPerfect    = zeros(nTrials, 1);
    perTrialImperfect  = zeros(nTrials, 1);
    perTrialRatioPower = zeros(nTrials, 1);

    for trialIndex = 1:nTrials

        onePoolEntry = realizationPool{trialIndex};

        ch               = onePoolEntry.ch;
        hHat = onePoolEntry.hHat;

        trueTypicalCascaded = ch.g(:, :, 1);

        receivedPhaseTwo = IrsSystem.computeReceivedSignal(ch, ...
            phaseTwoDesign.A, phaseTwoDesign.Phi, ...
            p, sigma2);

        estimatedTypicalCascaded = ChannelEstimation.estimateTypicalCascadedLmmse( ...
            receivedPhaseTwo, hHat, ...
            phaseTwoDesign.A, phaseTwoDesign.Phi, ...
            noiseCovariancePhaseTwo, cascadedCorrelationMatrix, ...
            p);

        effectiveSignal = zeros(M, ...
            phaseThreeDesign.phaseLength);

        for slotIndex = 1:phaseThreeDesign.phaseLength

            activeUserIndex = phaseThreeDesign.activeUser(slotIndex);
            activeElements  = phaseThreeDesign.activeElements{slotIndex};

            signalPart = sqrt(p) ...
                * trueTypicalCascaded(:, activeElements) ...
                * ch.lambda(activeElements, activeUserIndex);

            residualDirect = sqrt(p) ...
                * (ch.h(:, activeUserIndex) ...
                - hHat(:, activeUserIndex));

            effectiveSignal(:, slotIndex) = signalPart + residualDirect ...
                + onePoolEntry.phaseThreeNoise(:, slotIndex);

        end

        estimatesPerfect = ChannelEstimation.estimateRatioCoefficientsLmmse(effectiveSignal, ...
            trueTypicalCascaded, phaseThreeDesign, loss, corr, ...
            par, tau1);

        estimatesImperfect = ChannelEstimation.estimateRatioCoefficientsLmmse(effectiveSignal, ...
            estimatedTypicalCascaded, phaseThreeDesign, loss, ...
            corr, par, tau1);

        trueRatios = ch.lambda(:, 2:K);

        perTrialPerfect(trialIndex) = sum(sum(abs( ...
            estimatesPerfect(:, 2:K) - trueRatios).^2));
        perTrialImperfect(trialIndex) = sum(sum(abs( ...
            estimatesImperfect(:, 2:K) - trueRatios).^2));
        perTrialRatioPower(trialIndex) = sum(sum(abs(trueRatios).^2));

        theoreticalError = ChannelEstimation.computePhaseThreeMse(trueTypicalCascaded, ...
            phaseThreeDesign, loss, corr, par, ...
            tau1);
        perTrialTheory(trialIndex) = theoreticalError.totalMse;

    end

    denominatorValue = SimTools.aggregateHeavyTailedSample(perTrialRatioPower, aggregationMode);

    normalizedMseTheory(pointIndex) = ...
        SimTools.aggregateHeavyTailedSample(perTrialTheory, aggregationMode) / denominatorValue;
    normalizedMsePerfectCascaded(pointIndex) = ...
        SimTools.aggregateHeavyTailedSample(perTrialPerfect, aggregationMode) / denominatorValue;
    normalizedMseImperfect(pointIndex) = ...
        SimTools.aggregateHeavyTailedSample(perTrialImperfect, aggregationMode) / denominatorValue;


end

figureHandle = figure('Color', 'w', 'Position', [100, 100, 640, 480]);
hold on; grid on; box on;

semilogy(phaseTwoLengthList, normalizedMseTheory, ...
    'Color', [1 0 0], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 'x', 'MarkerSize', 8, ...
    'DisplayName', 'Theoretical Performance with Perfect g_{1,n}');

semilogy(phaseTwoLengthList, normalizedMsePerfectCascaded, ...
    'Color', [0 0.7 0], 'LineStyle', '--', 'LineWidth', 1.2, ...
    'Marker', 'o', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Monte Carlo Simulation with Perfect g_{1,n}');

semilogy(phaseTwoLengthList, normalizedMseImperfect, ...
    'Color', [0.55 0.27 0.07], 'LineStyle', '-', 'LineWidth', 1.2, ...
    'Marker', 's', 'MarkerSize', 7, 'MarkerFaceColor', 'none', ...
    'DisplayName', 'Monte Carlo Simulation with Imperfect g_{1,n}');

set(gca, 'YScale', 'log');
xlabel('Pilot Sequence Length in Phase II', 'FontSize', 11);
ylabel('Normalized MSE', 'FontSize', 11);
xlim([32, 64]); ylim([1e-4, 1e-1]);
set(gca, 'XTick', 32:4:64);
set(gca, 'YTick', 10.^(-4:-1));
set(gca, 'FontSize', 10);
legend('Location', 'northeast', 'FontSize', 8);
hold off;

results.phaseTwoLengthList           = phaseTwoLengthList;
results.normalizedMseTheory          = normalizedMseTheory;
results.normalizedMsePerfectCascaded = normalizedMsePerfectCascaded;
results.normalizedMseImperfect       = normalizedMseImperfect;
results.nTrials               = nTrials;
results.aggregationMode              = aggregationMode;
results.typicalUserDistanceToIrs     = typicalUserDistanceToIrs;

if saveToFile
    resultsFolder = fullfile(fileparts(mfilename('fullpath')), 'Results');
    if ~exist(resultsFolder, 'dir'), mkdir(resultsFolder); end
    print(figureHandle, fullfile(resultsFolder, 'Figure5.png'), '-dpng', '-r200');
    savefig(figureHandle, fullfile(resultsFolder, 'Figure5.fig'));
    save(fullfile(resultsFolder, 'Figure5.mat'), 'results');
end

end
